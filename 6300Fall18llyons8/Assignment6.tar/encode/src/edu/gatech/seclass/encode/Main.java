package edu.gatech.seclass.encode;

public class Main {

/*
Empty Main class for compiling Assignment 6.
DO NOT ALTER THIS CLASS or implement it.
 */

    public static void main(String[] args) {
        // Empty Skeleton Method
    }

    private static void usage() {
        System.err.println("Usage: encode [-n [int]] [-r int | -l int] [-c char] <filename>");
    }

}